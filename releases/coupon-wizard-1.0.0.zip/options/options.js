import { getSettings, saveSettings, getSources, saveSources } from '../lib/store.js';

const $ = id => document.getElementById(id);
let sources = [];

function renderSources() {
  $('sources').replaceChildren(...sources.map((s, i) => {
    const li = document.createElement('li');
    li.innerHTML = `
      <label class="switch"><input type="checkbox"><span></span></label>
      <div class="info"><div class="name"></div><div class="url"></div></div>
      <span class="pill"></span>`;
    const cb = li.querySelector('input'); cb.checked = s.enabled;
    cb.onchange = () => { sources[i].enabled = cb.checked; saveSources(sources); };
    li.querySelector('.name').textContent = s.name;
    li.querySelector('.url').textContent = s.url;
    li.querySelector('.pill').textContent = s.type;
    return li;
  }));
}

$('save').onclick = async () => {
  const settings = await getSettings();
  settings.cacheMinutes = +$('cacheMinutes').value || 60;
  settings.maxAttempts = +$('maxAttempts').value || 12;
  settings.applyTimeoutMs = +$('applyTimeoutMs').value || 6000;
  settings.tryUnknownThreshold = $('tryUnknownThreshold').checked;
  settings.affiliate = { link: $('affLink').value.trim() };
  if (settings.affiliate.link && !/^https:\/\/s\.click\.aliexpress\.com\//.test(settings.affiliate.link)) {
    $('saved').textContent = 'The tracking link should start with https://s.click.aliexpress.com/'; return;
  }
  await saveSettings(settings);
  $('saved').textContent = 'Saved ✓';
  setTimeout(() => ($('saved').textContent = ''), 2000);
};

(async function init() {
  sources = await getSources();
  renderSources();
  const s = await getSettings();
  $('cacheMinutes').value = s.cacheMinutes;
  $('maxAttempts').value = s.maxAttempts;
  $('applyTimeoutMs').value = s.applyTimeoutMs;
  $('tryUnknownThreshold').checked = s.tryUnknownThreshold;
  $('affLink').value = s.affiliate.link || '';
})();
