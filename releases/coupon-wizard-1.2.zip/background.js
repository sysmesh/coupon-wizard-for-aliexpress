/**
 * Background service worker.
 *  - Fetches the coupon sources (the only network traffic this extension makes),
 *    parses them locally and caches the result in chrome.storage.local.
 *  - Answers GET_COUPONS messages from the popup, and fetches once more when the
 *    shopper grants an optional source its host permission.
 *  - Answers GET_RATES: public exchange rates, asked for only when a cart and a
 *    promo code are in different currencies, and kept in memory (session storage),
 *    never on disk.
 * No cart data, URLs or personal data ever leave the browser.
 */
import {
  PARSERS_BY_TYPE,
  DAY_MS,
  consolidate,
  dropExpired,
  forRegion,
  parseBeeDealsListing,
  parseBeeDealsPost,
} from "./lib/parsers.js";
import {
  getSettings,
  getSources,
  getCache,
  saveCache,
  getShipTo,
} from "./lib/store.js";
import {
  CART_URL,
  CARRY_FORWARD_MAX_MS,
  RATE_SOURCES,
  RATES_FETCH_TIMEOUT_MS,
  RATES_MAX_STALE_MS,
  RATES_RETRY_AFTER_MS,
  RATES_SESSION_KEY,
  RATES_TTL_MS,
  FETCH_TIMEOUT_MS,
  sourceApplies,
  sourceOriginPattern,
} from "./lib/sources.js";
import { MESSAGES } from "./lib/messages.js";
import { parseRates } from "./lib/currency.js";

/**
 * GET a public page as text, without cookies, giving up after `timeoutMs`.
 * @param {string} url
 * @param {number} [timeoutMs]
 * @returns {Promise<string>}
 * @throws {Error} on a non-2xx status, a network failure or a timeout
 */
async function fetchText(url, timeoutMs = FETCH_TIMEOUT_MS) {
  const res = await fetch(url, {
    credentials: "omit",
    cache: "no-store",
    signal: AbortSignal.timeout(timeoutMs),
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.text();
}

/**
 * @typedef {import("./lib/parsers.js").Coupon} Coupon
 * @typedef {{coupons: Coupon[], carried: Coupon[], warnings: string[]}} FetchOutcome
 *   `coupons` were read just now; `carried` are kept from the last good read for the
 *   parts that failed; `warnings` describe those parts.
 */

/**
 * The coupons from an earlier read that may stand in for a read that failed: not
 * older than CARRY_FORWARD_MAX_MS, and still inside the source's own post-age limit.
 * @param {Coupon[]} previous the source's coupons in the cache; ones stored by an
 *   older version have no `fetchedAt` and are given the cache's own (see loadCoupons)
 * @param {Object} source an entry of DEFAULT_SOURCES
 * @param {number} [now] epoch ms
 * @returns {Coupon[]}
 */
function carryForward(previous, source, now = Date.now()) {
  return previous.filter(
    (c) =>
      now - (c.fetchedAt ?? 0) <= CARRY_FORWARD_MAX_MS &&
      (source.maxPostAgeDays == null ||
        now - (c.postedAt ?? c.seenAt ?? 0) <= source.maxPostAgeDays * DAY_MS),
  );
}

/**
 * Bee.Deals: read the store listing, then each recent coupon post it links to.
 * A post that cannot be read keeps its codes from the last good read and is
 * reported as a warning; all of them failing fails the source.
 * @param {Object} source a 'bee-deals' entry of DEFAULT_SOURCES
 * @param {{source: string, url: string}} meta
 * @param {Coupon[]} previous the source's coupons in the cache
 * @returns {Promise<FetchOutcome>}
 * @throws {Error} when the listing or every post is unreadable
 */
async function fetchBeeDeals(source, meta, previous) {
  const posts = parseBeeDealsListing(await fetchText(source.url), {
    url: source.url,
    maxPosts: source.maxPosts,
  });
  const results = await Promise.allSettled(
    posts.map(async (post) =>
      parseBeeDealsPost(await fetchText(post.url), {
        ...meta,
        link: post.url,
        maxPostAgeDays: source.maxPostAgeDays,
      }),
    ),
  );
  const failed = new Set(
    posts.filter((_, i) => results[i].status === "rejected").map((p) => p.url),
  );
  if (posts.length && failed.size === posts.length) throw results[0].reason;
  return {
    coupons: results
      .filter((r) => r.status === "fulfilled")
      .flatMap((r) => r.value),
    carried: carryForward(
      previous.filter((c) => failed.has(c.link)),
      source,
    ),
    warnings: failed.size
      ? [MESSAGES.postsUnreadable(failed.size, posts.length)]
      : [],
  };
}

/** Sources that need more than one request. Everything else uses PARSERS_BY_TYPE. */
const FETCHERS_BY_TYPE = {
  "bee-deals": fetchBeeDeals,
};

/**
 * Read one source. Coupons read now are stamped with the time and the source's regions.
 * @param {Object} source an entry of DEFAULT_SOURCES
 * @param {Coupon[]} previous the source's coupons in the cache
 * @returns {Promise<{coupons: Coupon[], warnings: string[]}>}
 * @throws {Error} when the source cannot be fetched or its type is unknown
 */
async function fetchSource(source, previous) {
  const meta = { source: source.id, url: source.url };
  const fetcher = FETCHERS_BY_TYPE[source.type];
  const parser = PARSERS_BY_TYPE[source.type];
  if (!fetcher && !parser)
    throw new Error(`Unknown source type "${source.type}"`);
  const outcome = fetcher
    ? await fetcher(source, meta, previous)
    : {
        coupons: parser(await fetchText(source.url), meta),
        carried: [],
        warnings: [],
      };
  const fetchedAt = Date.now();
  // Codes from a regional source only work for that ship-to country.
  const tags = source.regions?.length ? { regions: source.regions } : {};
  return {
    coupons: [
      ...outcome.coupons.map((c) => ({ ...c, fetchedAt, ...tags })),
      ...outcome.carried,
    ],
    warnings: outcome.warnings,
  };
}

/**
 * Fetch (or reuse) the coupon list for a shopper whose AliExpress ship-to country
 * is `shipTo` (ISO code, or null when unknown). Regional sources are only contacted
 * for their own countries. Returns the list to offer right now plus `needsPermission`:
 * enabled sources that fit this shopper but whose optional host permission was not
 * granted yet.
 *
 * The cache keeps every copy of every code as the sources gave them; which ones are
 * valid is decided here on each call, because that changes while the cache is fresh.
 * @param {{force?: boolean, shipTo?: string|null}} [options]
 * @returns {Promise<{fetchedAt: number, coupons: Coupon[], errors: {source: string, message: string, partial?: boolean}[], sourceKey?: string, fromCache: boolean, needsPermission: {id: string, name: string, origin: string}[]}>}
 */
async function loadCoupons({ force = false, shipTo = null } = {}) {
  const [settings, sources, cache] = await Promise.all([
    getSettings(),
    getSources(),
    getCache(),
  ]);

  const readable = [];
  const needsPermission = [];
  const permissionErrors = [];
  for (const s of sources) {
    if (!s.enabled || !sourceApplies(s, shipTo)) continue;
    const origin = sourceOriginPattern(s);
    if (await chrome.permissions.contains({ origins: [origin] })) {
      readable.push(s);
    } else if (s.optionalPermission) {
      needsPermission.push({ id: s.id, name: s.name, origin });
    } else {
      permissionErrors.push({
        source: s.name,
        message: MESSAGES.missingHostPermission,
      });
    }
  }

  const result = (c, fromCache) => ({
    ...c,
    fromCache,
    coupons: consolidate(forRegion(c.coupons, shipTo)),
    errors: [...permissionErrors, ...(c.errors || [])],
    needsPermission,
  });

  // The cache is only reusable for the same set of sources: a different ship-to
  // country, a toggled source or a newly granted permission all change that set.
  // A cache written before source sets were tracked has no key and counts as stale.
  const sourceKey = readable
    .map((s) => s.id)
    .sort()
    .join(",");
  const fresh = Date.now() - cache.fetchedAt < settings.cacheMinutes * 60000;
  if (
    fresh &&
    !force &&
    cache.coupons.length &&
    cache.sourceKey === sourceKey
  )
    return result(cache, true);

  const all = [];
  const errors = [];
  await Promise.all(
    readable.map(async (s) => {
      const previous = cache.coupons
        .filter((c) => c.source === s.id)
        .map((c) => ({ ...c, fetchedAt: c.fetchedAt ?? cache.fetchedAt }));
      try {
        const { coupons, warnings } = await fetchSource(s, previous);
        all.push(...coupons);
        errors.push(
          ...warnings.map((message) => ({
            source: s.name,
            message,
            partial: true,
          })),
        );
      } catch (e) {
        errors.push({ source: s.name, message: e.message });
        // Keep what this source gave last time (for a limited time), so one bad
        // request does not take its codes away until the next refresh.
        all.push(...carryForward(previous, s));
      }
    }),
  );

  const next = {
    fetchedAt: Date.now(),
    coupons: dropExpired(all),
    errors,
    sourceKey,
  };
  await saveCache(next);
  return result(next, false);
}

/**
 * Refreshes in flight, by ship-to country, so simultaneous callers share one set of
 * fetches (the popup and the permission listener can both ask right after a grant).
 * There is one stored cache for all of them: two runs for different countries that
 * overlap save in turn and the later one stays. That costs the other country a
 * refetch on its next call (its source set no longer matches), never a wrong list.
 * @type {Map<string, ReturnType<typeof loadCoupons>>}
 */
const inFlight = new Map();

/**
 * `loadCoupons`, joining a run already under way for the same ship-to country.
 * A forced request accepts that run only if it really fetched; if it merely served
 * the cache, a run of its own follows. Any caller that joined a run which then
 * failed makes one attempt of its own.
 * @param {{force?: boolean, shipTo?: string|null}} [options]
 * @returns {ReturnType<typeof loadCoupons>}
 */
export function refreshCoupons({ force = false, shipTo = null } = {}) {
  const key = String(shipTo);
  const running = inFlight.get(key);
  if (running) {
    const again = () => refreshCoupons({ force, shipTo });
    return running.then((r) => (force && r.fromCache ? again() : r), again);
  }
  const promise = loadCoupons({ force, shipTo }).finally(() =>
    inFlight.delete(key),
  );
  inFlight.set(key, promise);
  return promise;
}

/**
 * @typedef {{rates: Record<string, number>, at: number, provider: {name: string, site: string}, failedAt?: number}} RatesEntry
 *   `rates` are units per one US dollar; `at` is when they were fetched (epoch ms);
 *   `failedAt` is when every provider last failed to refresh them.
 * @typedef {RatesEntry | {failedAt: number}} StoredRates
 *   What session storage holds: rates, or only the time of a failure when there are none.
 */

/**
 * Exchange rates, from memory while they are fresh, else from the first provider
 * that answers. Kept in chrome.storage.session: that lives in memory only, and
 * outlasts the service worker going to sleep, so the providers are asked rarely.
 * When every provider fails, rates that have gone stale (but not older than
 * RATES_MAX_STALE_MS) are still better than none, and the providers are left alone
 * for RATES_RETRY_AFTER_MS.
 * @returns {Promise<RatesEntry>}
 * @throws {Error} when there are no usable rates
 */
async function loadRates() {
  /** @type {StoredRates|undefined} */
  const stored = (await chrome.storage.session.get(RATES_SESSION_KEY))[
    RATES_SESSION_KEY
  ];
  const now = Date.now();
  // An age below zero means the clock was set back: not to be trusted as fresh.
  const age = stored?.rates ? now - stored.at : NaN;
  if (age >= 0 && age < RATES_TTL_MS) return stored;
  const usable = age >= 0 && age < RATES_MAX_STALE_MS ? stored : null;
  const sinceFailure = now - (stored?.failedAt ?? 0);
  const backingOff = sinceFailure >= 0 && sinceFailure < RATES_RETRY_AFTER_MS;

  if (!backingOff) {
    for (const source of RATE_SOURCES) {
      try {
        const entry = {
          rates: parseRates(
            JSON.parse(await fetchText(source.url, RATES_FETCH_TIMEOUT_MS)),
          ),
          at: Date.now(),
          provider: { name: source.name, site: source.site },
        };
        await chrome.storage.session.set({ [RATES_SESSION_KEY]: entry });
        return entry;
      } catch {
        /* try the next provider */
      }
    }
    await chrome.storage.session.set({
      [RATES_SESSION_KEY]: { ...(usable ?? {}), failedAt: Date.now() },
    });
  }
  if (usable) return usable;
  throw new Error(MESSAGES.ratesUnavailable);
}

/** The rates request in flight, so simultaneous callers share one fetch. */
let ratesInFlight = null;

/**
 * `loadRates`, shared between callers that overlap.
 * @returns {Promise<RatesEntry>}
 */
export function getRates() {
  ratesInFlight ??= loadRates().finally(() => {
    ratesInFlight = null;
  });
  return ratesInFlight;
}

// A just-granted optional host permission makes a new source readable. Fetch right
// away: the popup that asked may have been closed by Chrome's permission dialog.
chrome.permissions.onAdded.addListener(async () => {
  try {
    await refreshCoupons({ shipTo: await getShipTo() });
  } catch {
    /* the next popup open fetches again */
  }
});

/**
 * "Support us" flow. The affiliate tracking link records the referral during the
 * s.click redirect chain, so we send the tab through it and then bring it back to
 * the page the user was on (cart / checkout):
 *   1. popup → SUPPORT_CLICK {tabId, returnUrl, affiliateLink}
 *   2. we watch the tab; once the redirect chain lands on an AliExpress page and
 *      stays put for SETTLE_MS, we navigate back to returnUrl
 *   3. for GUARD_MS after that, any stray navigation away (the landing page
 *      sometimes fires a late client-side redirect) is pushed back once more.
 * State lives in chrome.storage.session so a restarted service worker can continue.
 */
const SETTLE_MS = 1200;
const GUARD_MS = 6000;
const FLOW_TTL_MS = 90_000;
const settleTimers = new Map();

const isClickRedirect = (url) =>
  /^https:\/\/s\.click\.aliexpress\./.test(url || "");
const isAliPage = (url) =>
  /^https:\/\/[^/]*aliexpress\.(com|us)\//.test(url || "") &&
  !isClickRedirect(url);
const samePage = (a, b) => {
  try {
    const u = new URL(a),
      v = new URL(b);
    return u.origin + u.pathname === v.origin + v.pathname;
  } catch {
    return false;
  }
};

async function getFlow(tabId) {
  const { supportFlow } = await chrome.storage.session.get("supportFlow");
  if (!supportFlow || supportFlow.tabId !== tabId) return null;
  if (Date.now() - supportFlow.startedAt > FLOW_TTL_MS) {
    await endFlow();
    return null;
  }
  return supportFlow;
}
const setFlow = (flow) => chrome.storage.session.set({ supportFlow: flow });
const endFlow = () => chrome.storage.session.remove("supportFlow");

async function startSupportFlow(tabId, returnUrl, affiliateLink) {
  await setFlow({
    tabId,
    returnUrl,
    phase: "redirecting",
    retried: false,
    startedAt: Date.now(),
  });
  await chrome.tabs.update(tabId, { url: affiliateLink });
  // Safety net: if the redirect chain produced no further events, check the tab directly.
  setTimeout(async () => {
    const flow = await getFlow(tabId);
    if (flow?.phase !== "redirecting" || settleTimers.has(tabId)) return;
    const tab = await chrome.tabs.get(tabId).catch(() => null);
    if (tab && isAliPage(tab.url)) {
      await setFlow({ ...flow, phase: "returning", returnedAt: Date.now() });
      chrome.tabs.update(tabId, { url: flow.returnUrl }).catch(endFlow);
    }
  }, 8000);
}

chrome.tabs.onUpdated.addListener(async (tabId, info, tab) => {
  const flow = await getFlow(tabId);
  if (!flow) return;
  const url = info.url || tab.url || "";

  if (flow.phase === "redirecting") {
    // Debounce: every tab event (navigation, load, title, favicon…) re-arms the timer;
    // once the tab has been quiet for SETTLE_MS on an AliExpress page, go back.
    clearTimeout(settleTimers.get(tabId));
    if (!isAliPage(url)) return; // still on s.click (or elsewhere) — keep waiting
    settleTimers.set(
      tabId,
      setTimeout(async () => {
        if (!(await getFlow(tabId))) return;
        await setFlow({ ...flow, phase: "returning", returnedAt: Date.now() });
        chrome.tabs.update(tabId, { url: flow.returnUrl }).catch(endFlow);
      }, SETTLE_MS),
    );
    return;
  }

  if (flow.phase === "returning") {
    if (Date.now() - flow.returnedAt > GUARD_MS) {
      await endFlow();
      return;
    }
    if (
      info.url &&
      !samePage(info.url, flow.returnUrl) &&
      !isClickRedirect(info.url)
    ) {
      // A late redirect pulled the tab away from the return page — push back once.
      if (flow.retried) {
        await endFlow();
        return;
      }
      await setFlow({ ...flow, retried: true, returnedAt: Date.now() });
      chrome.tabs.update(tabId, { url: flow.returnUrl }).catch(endFlow);
    }
  }
});

chrome.tabs.onRemoved.addListener(async (tabId) => {
  if (await getFlow(tabId)) await endFlow();
});

/**
 * "Open checkout": open the cart (in the shopper's tab when it is already on
 * AliExpress, else a new tab), wait for it to load, then have the content script
 * press the cart's Checkout button.
 */
const CART_LOAD_TIMEOUT_MS = 20_000;
const CART_POLL_MS = 300;
const isCartPage = (url) => {
  try {
    return (
      isAliPage(url) && new URL(url).pathname === new URL(CART_URL).pathname
    );
  } catch {
    return false;
  }
};

async function openCheckout(tabId) {
  const tab =
    tabId != null ? await chrome.tabs.get(tabId).catch(() => null) : null;
  let target = tab;
  if (!tab || !isCartPage(tab.url)) {
    target =
      tab && isAliPage(tab.url)
        ? await chrome.tabs.update(tab.id, { url: CART_URL })
        : await chrome.tabs.create({ url: CART_URL });
  }
  // Poll rather than listen: the content script may not be listening yet even after "complete".
  const deadline = Date.now() + CART_LOAD_TIMEOUT_MS;
  while (Date.now() < deadline) {
    const t = await chrome.tabs.get(target.id).catch(() => null);
    if (!t) return { clicked: false };
    if (t.status === "complete" && isCartPage(t.url)) {
      const res = await chrome.tabs
        .sendMessage(t.id, { type: "ACW_CLICK_CHECKOUT" })
        .catch(() => null);
      if (res) return res;
    }
    await new Promise((r) => setTimeout(r, CART_POLL_MS));
  }
  return { clicked: false };
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === "GET_COUPONS") {
    refreshCoupons({ force: !!msg.force, shipTo: msg.shipTo || null }).then(
      sendResponse,
      (e) => sendResponse({ error: e.message }),
    );
    return true; // async
  }
  if (msg?.type === "GET_RATES") {
    getRates().then(sendResponse, (e) => sendResponse({ error: e.message }));
    return true;
  }
  if (msg?.type === "OPEN_CHECKOUT") {
    openCheckout(msg.tabId).then(sendResponse, (e) =>
      sendResponse({ error: e.message }),
    );
    return true;
  }
  if (msg?.type === "SUPPORT_CLICK") {
    startSupportFlow(msg.tabId, msg.returnUrl, msg.affiliateLink).then(
      () => sendResponse({ ok: true }),
      (e) => sendResponse({ error: e.message }),
    );
    return true;
  }
  return false;
});
