import { getSettings, saveSettings, getSources, saveSources } from '../lib/store.js';
import { sourceOriginPattern, RATE_SOURCES } from '../lib/sources.js';
import { MESSAGES } from '../lib/messages.js';

const $ = id => document.getElementById(id);
let sources = [];
/** Switch changes are saved one after another, so two quick toggles cannot overwrite each other. */
let saving = Promise.resolve();

/**
 * A source counts as on only when its host permission is there too: an optional
 * source is enabled by default but stays idle until the shopper grants its site.
 * @returns {Promise<void>}
 */
async function renderSources() {
  const granted = await Promise.all(sources.map(s =>
    !s.optionalPermission || chrome.permissions.contains({ origins: [sourceOriginPattern(s)] }).catch(() => false)));
  $('sources').replaceChildren(...sources.map((s, i) => {
    const li = document.createElement('li');
    li.innerHTML = `
      <label class="switch"><input type="checkbox"><span></span></label>
      <div class="info"><div class="name"></div><div class="url"></div></div>
      <span class="pill"></span>`;
    const cb = li.querySelector('input'); cb.checked = s.enabled && granted[i];
    cb.onchange = async () => {
      // An optional source needs its host permission; Chrome asks the shopper here.
      if (cb.checked && s.optionalPermission) {
        const allowed = await chrome.permissions.request({ origins: [sourceOriginPattern(s)] }).catch(() => false);
        if (!allowed) { cb.checked = false; return; }
      }
      // Switched off: hand the optional site access back as well.
      if (!cb.checked && s.optionalPermission) {
        await chrome.permissions.remove({ origins: [sourceOriginPattern(s)] }).catch(() => false);
      }
      // Read the stored list again before saving: the popup may have switched another
      // source off since this page loaded, and that must not be undone here.
      const enabled = cb.checked;
      const save = saving.then(async () => {
        sources = (await getSources()).map(x => x.id === s.id ? { ...x, enabled } : x);
        await saveSources(sources);
      });
      saving = save.catch(() => {}); // a failed save must not block the next one
      try { await save; } catch { cb.checked = !enabled; } // not stored: show the real state
    };
    li.querySelector('.name').textContent = s.name;
    li.querySelector('.url').textContent = s.regions?.length ? MESSAGES.regionOnly(s.url, s.regions) : s.url;
    li.querySelector('.pill').textContent = s.type;
    return li;
  }));
}

$('save').onclick = async () => {
  const settings = await getSettings();
  settings.cacheMinutes = +$('cacheMinutes').value || 60;
  settings.maxAttempts = +$('maxAttempts').value || 12;
  settings.applyTimeoutMs = +$('applyTimeoutMs').value || 6000;
  settings.tryUnknownThreshold = $('tryUnknownThreshold').checked;
  settings.affiliate = { link: $('affLink').value.trim() };
  if (settings.affiliate.link && !/^https:\/\/s\.click\.aliexpress\.com\//.test(settings.affiliate.link)) {
    $('saved').textContent = 'The tracking link should start with https://s.click.aliexpress.com/'; return;
  }
  await saveSettings(settings);
  $('saved').textContent = 'Saved ✓';
  setTimeout(() => ($('saved').textContent = ''), 2000);
};

(async function init() {
  // The exchange-rate provider that is asked first; its terms require naming it.
  $('rates-provider').textContent = RATE_SOURCES[0].name;
  $('rates-provider').href = RATE_SOURCES[0].site;
  sources = await getSources();
  await renderSources();
  const s = await getSettings();
  $('cacheMinutes').value = s.cacheMinutes;
  $('maxAttempts').value = s.maxAttempts;
  $('applyTimeoutMs').value = s.applyTimeoutMs;
  $('tryUnknownThreshold').checked = s.tryUnknownThreshold;
  $('affLink').value = s.affiliate.link || '';
})();
