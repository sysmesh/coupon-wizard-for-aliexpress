import { eligibleFor } from '../lib/parsers.js';
import { getSettings, getSources, saveSources } from '../lib/store.js';
import { affiliateUrl, CONVERSION_TOLERANCE } from '../lib/sources.js';
import { BASE_CURRENCY, currencyCode, couponCurrency, lacksRates, toBase } from '../lib/currency.js';
import { MESSAGES } from '../lib/messages.js';

const $ = id => document.getElementById(id);
const el = {
  offsite: $('view-offsite'), nocheckout: $('view-nocheckout'), reloadView: $('view-reload'), reload: $('reload'), cart: $('view-cart'), total: $('total'), totalLabel: $('total-label'),
  editTotal: $('edit-total'), totalEdit: $('total-edit'), totalInput: $('total-input'), totalSave: $('total-save'),
  eligible: $('eligible'), eligibleSummary: $('eligible-summary'),
  updated: $('updated'), sourceErrors: $('source-errors'), run: $('run'), progress: $('progress'),
  progressCount: $('progress-count'), barFill: $('bar-fill'), attempts: $('attempts'), result: $('result'),
  refresh: $('refresh'), options: $('options'), support: $('support'),
  sourcePermission: $('source-permission'), sourcePermissionText: $('source-permission-text'),
  permissionAllow: $('permission-allow'), permissionDecline: $('permission-decline'),
  ratesNote: $('rates-note'), ratesConverted: $('rates-converted'), ratesLink: $('rates-link'), ratesMissing: $('rates-missing')
};

let tab, status, settings, coupons = [], eligible = [], totalOverride = null;
/** Exchange rates from the background ({ rates, at, provider }), or null when not needed or not available. */
let exchange = null;
/** True while the exchange rates are being fetched. */
let ratesPending = false;

const money = (n, cur = '') => n == null ? '—' : `${cur}${Number(n).toFixed(2)}`;
const ago = ts => {
  const m = Math.round((Date.now() - ts) / 60000);
  return m < 1 ? 'just now' : m < 60 ? `${m} min ago` : `${Math.round(m / 60)} h ago`;
};

async function activeTab() {
  const [t] = await chrome.tabs.query({ active: true, currentWindow: true });
  return t;
}

async function askPage(msg) {
  try { return await chrome.tabs.sendMessage(tab.id, msg); } catch { return null; }
}

function effectiveTotal() { return totalOverride ?? status?.total ?? null; }

/**
 * ISO code of the currency the cart total is shown in, or null when unknown. The
 * symbol next to the total is what the number is in, so it decides when it names
 * another currency ("₪", "C$"); a dollar sign may be any dollar, so there AliExpress's
 * own setting is asked first.
 * @returns {string|null}
 */
function cartCurrency() {
  const symbol = currencyCode(status?.currency);
  return symbol && symbol !== BASE_CURRENCY ? symbol : status?.currencyCode || symbol;
}

/**
 * The currencies that have to be converted to match codes against this cart: the
 * cart's and those of the codes written in another one. Empty when the cart's
 * currency is unknown or every code is in it. Codes whose currency cannot be told
 * are left out (they are compared as written), and so are codes with no minimum
 * spend (there is nothing to compare).
 * @returns {string[]} ISO codes
 */
function currenciesToConvert() {
  const cart = cartCurrency();
  if (!cart) return [];
  const others = new Set(coupons.filter(c => c.threshold != null).map(c => couponCurrency(c.currency)).filter(code => code && code !== cart));
  return others.size ? [cart, ...others] : [];
}

/**
 * Fetch exchange rates when the cart and a code are in different currencies.
 * @returns {Promise<void>}
 */
async function loadRates() {
  if (!currenciesToConvert().length || exchange) return;
  const res = await chrome.runtime.sendMessage({ type: 'GET_RATES' }).catch(() => null);
  exchange = res?.rates ? res : null;
}

/**
 * Show what the exchange rates did: the cart total in the base currency (for a cart
 * in another one) and the rates' attribution whenever rates were used, or a notice
 * when a needed rate is missing.
 * @param {number|null} total the cart total as shown on the page
 * @returns {void}
 */
function renderRates(total) {
  const cart = cartCurrency();
  const needed = currenciesToConvert();
  // Rates count as used only when they could convert something.
  const used = !!exchange && needed.some(code => code !== BASE_CURRENCY && toBase(1, code, exchange.rates) != null);
  el.ratesNote.classList.toggle('hidden', !used);
  if (used) {
    const converted = cart !== BASE_CURRENCY && total != null ? toBase(total, cart, exchange.rates) : null;
    el.ratesConverted.textContent = converted == null ? '' : MESSAGES.convertedTotal(`${BASE_CURRENCY} ${money(converted)}`);
    el.ratesLink.textContent = MESSAGES.ratesBy(exchange.provider.name);
    el.ratesLink.href = exchange.provider.site;
  }
  const missing = !ratesPending && lacksRates(needed, exchange?.rates);
  el.ratesMissing.classList.toggle('hidden', !missing);
  if (missing) el.ratesMissing.textContent = MESSAGES.ratesMissing;
}

function renderEligible() {
  const total = effectiveTotal();
  eligible = total == null ? [] : eligibleFor(coupons, total, {
    tryUnknownThreshold: settings.tryUnknownThreshold, limit: settings.maxAttempts,
    cartCurrency: cartCurrency(), rates: exchange?.rates ?? null, tolerance: CONVERSION_TOLERANCE
  });
  renderRates(total);
  if (ratesPending) eligible = []; // not matched yet: the list would be wrong
  el.eligible.replaceChildren(...eligible.map(c => {
    const li = document.createElement('li');
    const left = document.createElement('div');
    left.innerHTML = `<code></code> <span class="meta"></span>`;
    left.querySelector('code').textContent = c.code;
    left.querySelector('.meta').textContent = c.threshold != null ? `${c.currency}${c.discount} off ${c.currency}${c.threshold}+` : 'min. spend unknown';
    const copy = document.createElement('button');
    copy.className = 'link copy'; copy.textContent = 'copy';
    copy.onclick = () => { navigator.clipboard.writeText(c.code); copy.textContent = 'copied'; setTimeout(() => copy.textContent = 'copy', 1200); };
    li.append(left, copy);
    return li;
  }));
  el.eligibleSummary.textContent = ratesPending ? MESSAGES.converting : total == null
    ? 'Set the cart total to see matching codes'
    : `${eligible.length} of ${coupons.length} codes match a ${status?.currency || ''}${money(total)} cart`;
  el.run.disabled = !eligible.length || !!status?.running;
}

function renderStatus() {
  const total = effectiveTotal();
  el.total.textContent = total == null ? '—' : `${status?.currency || ''}${money(total)}`;
  el.totalLabel.textContent = totalOverride != null ? '(manual)' : status?.label ? `· "${status.label}"` : '';
  if (status?.lastRun && el.result.classList.contains('hidden')) renderResult(status.lastRun);
  renderEligible();
}

async function loadCoupons(force = false) {
  el.refresh.classList.add('spinning');
  const cache = await chrome.runtime.sendMessage({ type: 'GET_COUPONS', force, shipTo: status?.shipTo || null });
  el.refresh.classList.remove('spinning');
  coupons = cache?.coupons || [];
  el.updated.textContent = cache?.fetchedAt ? `updated ${ago(cache.fetchedAt)}` : '';
  const errs = cache?.errors || [];
  el.sourceErrors.classList.toggle('hidden', !errs.length);
  el.sourceErrors.textContent = errs.map(friendlyError).join(' ');
  renderPermissionPrompt(cache?.needsPermission || []);
  // Show the codes at once unless they first need converting; then say so while waiting.
  ratesPending = currenciesToConvert().length > 0 && !exchange;
  renderEligible();
  if (ratesPending) {
    await loadRates();
    ratesPending = false;
    renderEligible();
  }
}

/**
 * Some sources only serve one country and are not part of the install-time
 * permissions. When one fits this shopper, offer to switch it on: Chrome only
 * shows its permission dialog in response to a click.
 * @param {{id: string, name: string, origin: string}[]} pending sources waiting for their host permission
 * @returns {void}
 */
function renderPermissionPrompt(pending) {
  el.sourcePermission.classList.toggle('hidden', !pending.length);
  if (!pending.length) return;
  const names = pending.map(p => p.name).join(', ');
  const hosts = pending.map(p => new URL(p.origin.replace('/*', '/')).host).join(', ');
  el.sourcePermissionText.textContent = MESSAGES.permissionPrompt(names, hosts);
  el.permissionAllow.onclick = async () => {
    const granted = await chrome.permissions.request({ origins: pending.map(p => p.origin) }).catch(() => false);
    if (granted) loadCoupons();
  };
  el.permissionDecline.onclick = async () => {
    const declined = new Set(pending.map(p => p.id));
    const sources = await getSources();
    await saveSources(sources.map(s => declined.has(s.id) ? { ...s, enabled: false } : s));
    el.sourcePermission.classList.add('hidden');
  };
}

/**
 * Turn a raw fetch error into something a shopper can act on.
 * @param {{source: string, message?: string, partial?: boolean}} error `partial`: the source answered only in part
 * @returns {string}
 */
function friendlyError({ source, message = '', partial = false }) {
  const site = source.replace(/\s*\(.*\)\s*$/, ''); // "r/AliExpressCode (Reddit)" → "r/AliExpressCode"
  if (partial) return MESSAGES.partlyRead(site);
  if (/429/.test(message)) return `${site} is busy right now — try the ↻ button again in a minute.`;
  if (/40[13]/.test(message)) return `${site} refused the request. Try again later.`;
  if (/5\d\d/.test(message)) return `${site} is having trouble. Try again later.`;
  if (/fetch|network|Failed/i.test(message)) return `Couldn't reach ${site} — check your internet connection.`;
  return `${site} couldn't be read right now. Try again later.`;
}

function renderAttempt({ index, code, ok, message, total, stage }) {
  let li = el.attempts.querySelector(`[data-i="${index}"]`);
  if (!li) { li = document.createElement('li'); li.dataset.i = index; el.attempts.append(li); }
  li.className = stage === 'trying' ? 'trying' : ok ? 'ok' : 'bad';
  li.innerHTML = `<code></code><span class="msg"></span>`;
  li.querySelector('code').textContent = code;
  li.querySelector('.msg').textContent = stage === 'trying' ? 'trying…' : ok ? `✓ ${money(total, status?.currency)}` : (message || 'no');
  li.scrollIntoView({ block: 'nearest' });
}

function renderResult(r) {
  el.result.classList.remove('hidden', 'ok', 'bad');
  if (r.bestCode) {
    el.result.classList.add('ok');
    el.result.innerHTML = `<h3>Coupon applied 🎉</h3>
      <div class="big-code"></div>
      <p class="small"><span class="was"></span> → <b class="now"></b> · saved <b class="saved"></b></p>`;
    el.result.querySelector('.big-code').textContent = r.bestCode;
    el.result.querySelector('.was').textContent = money(r.baseline, r.currency);
    el.result.querySelector('.now').textContent = money(r.finalTotal, r.currency);
    el.result.querySelector('.saved').textContent = money(r.saved, r.currency);
  } else {
    el.result.classList.add('bad');
    const noBox = r.results?.length && r.results.every(x => x.message?.startsWith('Could not find'));
    el.result.innerHTML = `<h3></h3><p class="small"></p>${noBox ? '<p class="small"><b>Already on the checkout page? Make sure that the coupon box is expanded</b></p>' : ''}`;
    el.result.querySelector('h3').textContent = noBox ? 'Promo code box not found' : 'No coupon worked';
    el.result.querySelector('p').textContent = noBox
      ? 'This extension only works on the AliExpress checkout page. Open it and try again.'
      : `Tried ${r.tried} code${r.tried === 1 ? '' : 's'} ${ago(r.at)}. The codes may be used up already, or not valid for your region or cart.`;
  }
}

async function runWizard() {
  el.run.disabled = true;
  el.result.classList.add('hidden');
  el.progress.classList.remove('hidden');
  el.attempts.replaceChildren();
  el.barFill.style.width = '0%';
  el.progressCount.textContent = `0 / ${eligible.length}`;
  const res = await askPage({ type: 'ACW_RUN', coupons: eligible, settings });
  if (!res || res.error) {
    el.result.classList.remove('hidden'); el.result.classList.add('bad');
    el.result.innerHTML = `<h3>Couldn't run</h3><p class="small"></p>`;
    el.result.querySelector('p').textContent = 'Please refresh the AliExpress page and try again.';
  }
  el.run.disabled = false;
}

chrome.runtime.onMessage.addListener(msg => {
  if (msg?.type !== 'ACW_PROGRESS') return;
  if (msg.stage === 'trying' || msg.stage === 'result') {
    renderAttempt(msg);
    const done = msg.stage === 'result' ? msg.index + 1 : msg.index;
    el.progressCount.textContent = `${done} / ${eligible.length}`;
    el.barFill.style.width = `${(done / Math.max(1, eligible.length)) * 100}%`;
  }
  if (msg.stage === 'done') { el.barFill.style.width = '100%'; renderResult(msg); }
});

el.editTotal.onclick = () => { el.totalEdit.classList.toggle('hidden'); el.totalInput.focus(); };
el.totalSave.onclick = () => {
  const v = parseFloat(el.totalInput.value);
  totalOverride = Number.isFinite(v) && v > 0 ? v : null;
  el.totalEdit.classList.add('hidden');
  renderStatus();
};
el.totalInput.onkeydown = e => { if (e.key === 'Enter') el.totalSave.click(); };
el.refresh.onclick = () => loadCoupons(true);
el.options.onclick = () => chrome.runtime.openOptionsPage();
el.run.onclick = runWizard;

/**
 * Open the affiliate tracking link in the current tab (explicit user action), then
 * return the user to the page they were on (handled by background.js + content script).
 */
function setupSupportButton() {
  const affiliateLink = affiliateUrl(settings);
  if (!affiliateLink) return; // not configured → button stays hidden
  el.support.classList.remove('hidden');
  el.support.onclick = async () => {
    el.support.classList.add('done');
    await chrome.runtime.sendMessage({ type: 'SUPPORT_CLICK', tabId: tab.id, returnUrl: tab.url, affiliateLink });
    setTimeout(() => window.close(), 600);
  };
}

/** Open the cart and press its Checkout button (background.js does the work). */
function setupOpenCheckout(onAli) {
  for (const btn of document.querySelectorAll('.open-checkout')) {
    btn.onclick = async () => {
      chrome.runtime.sendMessage({ type: 'OPEN_CHECKOUT', tabId: onAli ? tab.id : null }).catch(() => {});
      setTimeout(() => window.close(), 300);
    };
  }
}

(async function init() {
  settings = await getSettings();
  tab = await activeTab();
  const onAli = /^https:\/\/[^/]*aliexpress\.(com|us)\//.test(tab?.url || '');
  setupOpenCheckout(onAli);
  if (!onAli) { el.offsite.classList.remove('hidden'); return; }

  status = await askPage({ type: 'ACW_STATUS' });
  // No answer: the content script isn't in this tab (it was open before install/update).
  if (!status) {
    el.reloadView.classList.remove('hidden');
    el.reload.onclick = () => { chrome.tabs.reload(tab.id); window.close(); };
    return;
  }
  // The Support button only makes sense where a purchase is about to happen.
  if (status?.hasCodeBox || ['cart', 'checkout'].includes(status?.kind)) setupSupportButton();
  // Only the checkout page has a promo code box. Anywhere else: explain, and
  // don't hit the coupon sources at all. On checkout, carry on even if the box
  // wasn't found yet: the run opens it again before typing the first code.
  if (!status.hasCodeBox && status.kind !== 'checkout') { el.nocheckout.classList.remove('hidden'); return; }

  el.cart.classList.remove('hidden');
  renderStatus();
  await loadCoupons();
})();
