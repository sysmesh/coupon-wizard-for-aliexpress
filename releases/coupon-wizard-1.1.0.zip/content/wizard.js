/**
 * The wizard: given a list of coupons, try them on the current page and keep
 * the one that yields the lowest total. Talks to the popup via runtime messages.
 * Author: Gilad Ariav.
 *
 * Messages handled:
 *   { type: 'ACW_STATUS' }                  -> { kind, total, currency, label, running, lastRun }
 *   { type: 'ACW_RUN', coupons, settings }  -> starts a run; progress is broadcast as ACW_PROGRESS
 *   { type: 'ACW_HIGHLIGHT' }               -> flashes the detected elements (debug aid)
 */
(() => {
  const A = window.__ACW_ADAPTER;
  if (!A) return;

  const state = { running: false, lastRun: null };

  // ---------- tiny toast (shadow DOM so AliExpress CSS can't touch it) ----------
  let toastHost;
  function toast(message, tone = 'info', ms = 6000) {
    if (!toastHost) {
      toastHost = document.createElement('div');
      toastHost.id = 'acw-toast-host';
      const root = toastHost.attachShadow({ mode: 'closed' });
      root.innerHTML = `<style>
        .t{position:fixed;right:20px;bottom:20px;z-index:2147483647;max-width:340px;padding:14px 16px;border-radius:14px;
           font:14px/1.4 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;color:#fff;background:#1f2937;
           box-shadow:0 12px 32px rgba(0,0,0,.25);display:flex;gap:10px;align-items:flex-start;
           animation:in .25s ease-out}
        .t.ok{background:#047857}.t.bad{background:#b91c1c}
        .t b{font-weight:600}
        @keyframes in{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}
      </style><div class="t"><span class="i">🎟️</span><div class="m"></div></div>`;
      document.documentElement.appendChild(toastHost);
      toastHost._el = root.querySelector('.t');
      toastHost._msg = root.querySelector('.m');
    }
    toastHost._el.className = 't ' + ({ ok: 'ok', bad: 'bad' }[tone] || '');
    toastHost._msg.innerHTML = message;
    toastHost.style.display = '';
    clearTimeout(toastHost._timer);
    toastHost._timer = setTimeout(() => { toastHost.style.display = 'none'; }, ms);
  }

  function progress(payload) {
    chrome.runtime.sendMessage({ type: 'ACW_PROGRESS', ...payload }).catch(() => {});
  }

  function fmt(amount, currency) {
    if (amount == null) return '—';
    return `${currency || ''}${amount.toFixed(2)}`;
  }

  async function run(coupons, settings = {}) {
    if (state.running) return { error: 'Already running' };
    state.running = true;
    const timeoutMs = settings.applyTimeoutMs || 6000;
    const start = A.readTotal();
    const currency = start?.currency || '';
    let baseline = start?.amount ?? null;
    let best = { code: null, total: baseline };
    const results = [];

    progress({ stage: 'start', baseline, currency, count: coupons.length });
    toast(`Trying <b>${coupons.length}</b> coupon${coupons.length === 1 ? '' : 's'} on your cart…`);

    try {
      for (let i = 0; i < coupons.length; i++) {
        const c = coupons[i];
        progress({ stage: 'trying', index: i, code: c.code, total: best.total });
        const r = await A.applyCode(c.code, { timeoutMs, baseline: best.total ?? baseline });
        const entry = { code: c.code, ok: r.ok, total: r.total, message: r.message, discount: c.discount, threshold: c.threshold };
        results.push(entry);
        progress({ stage: 'result', index: i, ...entry });

        if (r.ok && r.total != null && (best.total == null || r.total < best.total)) {
          best = { code: c.code, total: r.total };
        } else if (!r.ok && r.message?.startsWith('Could not find')) {
          break; // nothing more we can do on this page
        }
        await new Promise(res => setTimeout(res, 400));
      }

      // Make sure the best code is the one left applied.
      const last = results[results.length - 1];
      if (best.code && last && last.code !== best.code) {
        progress({ stage: 'reapply', code: best.code });
        await A.applyCode(best.code, { timeoutMs, baseline: A.readTotal()?.amount ?? baseline });
      }

      const finalTotal = A.readTotal()?.amount ?? best.total;
      const summary = {
        at: Date.now(), baseline, currency, finalTotal, bestCode: best.code,
        saved: baseline != null && finalTotal != null ? Math.max(0, baseline - finalTotal) : null,
        tried: results.length, results
      };
      state.lastRun = summary;

      if (best.code) {
        toast(`✅ Best code: <b>${best.code}</b><br>${fmt(baseline, currency)} → <b>${fmt(finalTotal, currency)}</b> (saved ${fmt(summary.saved, currency)})`, 'ok', 10000);
      } else if (!results.length || results.every(r => r.message?.startsWith('Could not find'))) {
        toast('Couldn\'t find the promo code box on this page. Open the checkout page and try again.', 'bad', 9000);
      } else {
        toast('<b>No coupon worked</b> for this cart.', 'bad', 9000);
      }
      progress({ stage: 'done', ...summary });
      return summary;
    } finally {
      state.running = false;
    }
  }

  async function status() {
    const kind = A.pageKind();
    // On checkout the promo code area is often collapsed, so the input isn't in
    // the DOM yet. Expand it (no-op if already open) before reporting.
    const input = kind === 'checkout' && !state.running ? await A.ensureCodeInput() : A.findCodeInput();
    const t = A.readTotal();
    return {
      kind, total: t?.amount ?? null, currency: t?.currency || '', label: t?.label || '',
      hasCodeBox: !!input, running: state.running, lastRun: state.lastRun, url: location.href
    };
  }

  function highlight() {
    const els = [A.readTotal() && findTotalEl(), A.findCodeInput()].filter(Boolean);
    for (const el of els) {
      const prev = el.style.outline;
      el.style.outline = '3px solid #f97316';
      setTimeout(() => { el.style.outline = prev; }, 2500);
    }
    return { highlighted: els.length };
  }
  function findTotalEl() {
    // Cheap re-derivation for the debug highlight only.
    return document.querySelector(A.SELECTORS.total.join(','));
  }

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg?.type === 'ACW_STATUS') { status().then(sendResponse, e => sendResponse({ error: e.message })); return true; }
    if (msg?.type === 'ACW_HIGHLIGHT') { sendResponse(highlight()); return false; }
    if (msg?.type === 'ACW_RUN') {
      run(msg.coupons || [], msg.settings || {}).then(sendResponse, e => sendResponse({ error: e.message }));
      return true;
    }
    return false;
  });
})();
