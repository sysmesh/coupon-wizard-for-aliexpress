/**
 * AliExpress page adapter — the ONLY file that knows about AliExpress's DOM.
 *
 * AliExpress changes its markup often. Everything here is driven by the
 * SELECTORS / PATTERNS tables below, so when something breaks, update those
 * first. Each finder tries explicit selectors first, then falls back to
 * text/attribute heuristics so the extension keeps working across redesigns.
 *
 * Exposed as window.__ACW_ADAPTER (content scripts share one isolated world).
 */
(() => {
  const SELECTORS = {
    // Containers that hold the order summary (used to scope the "total" search).
    summary: ['[class*="summary"]', '[class*="Summary"]', '[class*="order-total"]', '[class*="checkout"]', '[class*="cart"]'],
    // Elements that display the grand total.
    total: ['[class*="total-price"]', '[class*="totalPrice"]', '[class*="grand-total"]', '[class*="summary"] [class*="total"]'],
    // The promo/coupon code text box.
    codeInput: [
      'input[placeholder*="code" i]', 'input[placeholder*="coupon" i]', 'input[placeholder*="promo" i]',
      'input[name*="code" i]', 'input[class*="code" i]', 'input[class*="coupon" i]', 'input[aria-label*="code" i]'
    ],
    // Buttons that submit the code (searched near the input first).
    applyButton: ['button[class*="apply" i]', 'button[class*="code" i]', '[role="button"][class*="apply" i]', 'button[type="submit"]'],
    // Links/buttons that reveal the code box when it is collapsed.
    expander: ['[class*="promo-code"]', '[class*="promoCode"]', '[class*="coupon-code"]', '[class*="couponCode"]', '[class*="enter-code"]'],
    // The cart's "Checkout" button (fallback when the text match finds nothing).
    checkoutButton: ['button[class*="checkout" i]', '[role="button"][class*="checkout" i]', '[class*="checkout-btn" i]', '[class*="checkoutBtn" i]']
  };

  // How long to wait for the page to react (poll interval x number of tries).
  const WAIT = { pollMs: 250, expandTries: 8, checkoutTries: 40 };
  // How many ancestors up from the "Promo codes" title to look for its "Enter" action.
  const EXPANDER_ROW_DEPTH = 4;
  // Stop looking for feedback in containers with more text than this (the page body
  // always contains words like "error" or "minimum" somewhere).
  const FEEDBACK_MAX_CHARS = 300;

  const PATTERNS = {
    totalLabel: /^(order\s+)?(grand\s+)?total(\s*\(.*\))?\s*:?$/i,
    totalLabelLoose: /\btotal\b/i,
    expanderText: /(enter|add|use|have|got)?\s*(a\s+)?(promo|coupon|discount)\s*code|promo\s*codes?|coupon\s*codes?/i,
    // A bare section title ("Promo codes"), as opposed to text that merely mentions a code.
    expanderTitle: /^(promo|coupon|discount)\s*codes?:?$/i,
    // The action next to that title (AliExpress checkout: "Promo codes ........ Enter").
    expanderAction: /^(enter|add|apply|use|redeem|select)(\s+(a\s+)?((promo|coupon)\s+)?code)?$/i,
    applyText: /^(apply|use|ok|submit|redeem|add|confirm)$/i,
    checkoutText: /^(proceed\s+to\s+)?check\s*out(\s*\(\d+\))?$/i,
    errorText: /invalid|not\s+(valid|applicable|available|eligible)|expired|can'?t\s+be\s+used|cannot|unavailable|already\s+(used|applied)|doesn'?t\s+(exist|meet)|minimum|not\s+found|failed|error|limit|wrong/i,
    successText: /applied|success|saved|discount\s+applied/i,
    // Currency symbol/code followed by a number ("US $12.34", "€12,34", "₪ 1,234.50", "12.34$")
    money: /(?:(C\$|AU\$|R\$|M\$|US\s?\$|\$|€|£|₪|¥|USD|EUR|GBP|ILS)\s?)(\d{1,3}(?:[,.\s]\d{3})*(?:[.,]\d{1,2})?)|(\d{1,3}(?:[,.\s]\d{3})*(?:[.,]\d{1,2})?)\s?(C\$|AU\$|R\$|M\$|US\s?\$|\$|€|£|₪|¥|USD|EUR|GBP|ILS)/
  };

  const q = (sels, root = document) => {
    for (const s of sels) {
      try { const el = root.querySelector(s); if (el && isVisible(el)) return el; } catch { /* bad selector */ }
    }
    return null;
  };
  const qa = (sels, root = document) => {
    const out = [];
    for (const s of sels) { try { out.push(...root.querySelectorAll(s)); } catch { /* ignore */ } }
    return out.filter(isVisible);
  };

  function isVisible(el) {
    if (!(el instanceof Element)) return false;
    const r = el.getBoundingClientRect();
    if (!r.width && !r.height) return false;
    const cs = getComputedStyle(el);
    return cs.visibility !== 'hidden' && cs.display !== 'none';
  }

  function text(el) { return (el?.textContent || '').replace(/\s+/g, ' ').trim(); }

  /** Parse "US $1,234.56" → { amount: 1234.56, currency: 'US $' }. */
  function parseMoney(str) {
    const m = PATTERNS.money.exec(str || '');
    if (!m) return null;
    const currency = (m[1] || m[4] || '').replace(/\s+/g, '');
    let raw = m[2] || m[3];
    // Normalise thousands/decimal separators: last separator with 1-2 digits after it is the decimal point.
    raw = raw.replace(/\s/g, '');
    const lastSep = Math.max(raw.lastIndexOf('.'), raw.lastIndexOf(','));
    let amount;
    if (lastSep > -1 && raw.length - lastSep - 1 <= 2) {
      amount = parseFloat(raw.slice(0, lastSep).replace(/[.,]/g, '') + '.' + raw.slice(lastSep + 1));
    } else {
      amount = parseFloat(raw.replace(/[.,]/g, ''));
    }
    return Number.isFinite(amount) ? { amount, currency } : null;
  }

  /** Leaf-ish elements whose own text matches a predicate. */
  function findLabels(pred, maxLen = 40) {
    const out = [];
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_ELEMENT);
    for (let el = walker.nextNode(); el; el = walker.nextNode()) {
      if (el.children.length > 2) continue;
      const t = text(el);
      if (t && t.length <= maxLen && pred(t) && isVisible(el)) out.push(el);
    }
    return out;
  }

  /** Find the money value displayed next to a label element (same row/card). */
  function moneyNear(label) {
    let node = label;
    for (let i = 0; i < 4 && node; i++, node = node.parentElement) {
      const t = text(node);
      // Prefer the LAST money token in the container — totals are usually rendered after the label.
      const tokens = t.match(new RegExp(PATTERNS.money.source, 'g')) || [];
      for (let k = tokens.length - 1; k >= 0; k--) {
        const m = parseMoney(tokens[k]);
        if (m && m.amount > 0) return m;
      }
    }
    return null;
  }

  /** The cart/checkout grand total as { amount, currency, label }. */
  function readTotal() {
    const explicit = q(SELECTORS.total);
    if (explicit) { const m = parseMoney(text(explicit)); if (m) return { ...m, label: text(explicit).slice(0, 40) }; }

    for (const pred of [t => PATTERNS.totalLabel.test(t), t => PATTERNS.totalLabelLoose.test(t)]) {
      const labels = findLabels(pred);
      // Scan from the bottom of the page up — the grand total is usually the last "Total".
      for (const label of labels.reverse()) {
        const m = moneyNear(label);
        if (m) return { ...m, label: text(label) };
      }
    }
    return null;
  }

  // A code box found only because it appeared after the expander click (no placeholder
  // or name to match on later); remembered while it stays on the page.
  let revealedInput = null;
  function findCodeInput() {
    return q(SELECTORS.codeInput) || (revealedInput?.isConnected && isVisible(revealedInput) ? revealedInput : null);
  }

  function findExpander() {
    const explicit = qa(SELECTORS.expander).find(el => !el.querySelector('input'));
    if (explicit) return explicit.querySelector('a, button, [role="button"]') || explicit;
    const labels = findLabels(t => PATTERNS.expanderText.test(t), 60)
      .filter(el => ['A', 'BUTTON', 'SPAN', 'DIV', 'P'].includes(el.tagName));
    // Prefer a "Promo codes" title over text that only mentions a code ("₪4.00 coupon code if delayed").
    const titles = labels.filter(el => PATTERNS.expanderTitle.test(text(el)));
    // Wrappers match too (their text includes the link's); clicking a wrapper
    // never reaches the link's handler, so take the innermost match.
    const label = innermost(titles.length ? titles : labels);
    if (!label) return null;
    // The click handler often sits on an action beside the title ("Enter"), not on the title.
    let node = label.parentElement;
    for (let i = 0; i < EXPANDER_ROW_DEPTH && node; i++, node = node.parentElement) {
      const action = innermost([...node.querySelectorAll('*')]
        .filter(e => !label.contains(e) && isVisible(e) && PATTERNS.expanderAction.test(text(e))));
      if (action) return action.closest('a, button, [role="button"]') || action;
    }
    return label.closest('a, button, [role="button"]') || label;
  }

  /** First element of the list that contains no other element of the list. */
  function innermost(els) { return els.find(el => !els.some(o => o !== el && el.contains(o))) || null; }

  /** Visible free-text inputs (the code box may have no placeholder/name to match on). */
  function textInputs() {
    return [...document.querySelectorAll('input:not([type]), input[type="text"], input[type="search"]')].filter(isVisible);
  }

  function findApplyButton(input) {
    let node = input;
    for (let i = 0; i < 5 && node; i++, node = node.parentElement) {
      const btn = [...node.querySelectorAll('button, [role="button"], a')]
        .find(b => isVisible(b) && (PATTERNS.applyText.test(text(b)) || /apply|use/i.test(b.className)));
      if (btn) return btn;
    }
    return q(SELECTORS.applyButton);
  }

  /** Any visible error/success feedback near the input. */
  function readFeedback(input) {
    let node = input;
    for (let i = 0; i < 5 && node; i++, node = node.parentElement) {
      const t = text(node).replace(input.value, '');
      if (t.length > FEEDBACK_MAX_CHARS) break;
      if (PATTERNS.errorText.test(t)) return { kind: 'error', text: t.slice(0, 160) };
      if (PATTERNS.successText.test(t)) return { kind: 'success', text: t.slice(0, 160) };
    }
    return null;
  }

  /** Set a React-controlled input's value so the page notices. */
  function setInputValue(input, value) {
    const proto = Object.getPrototypeOf(input);
    const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
    input.focus();
    if (setter) setter.call(input, value); else input.value = value;
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
  }

  const sleep = ms => new Promise(r => setTimeout(r, ms));

  /** Reveal and return the code input, clicking an expander if needed. */
  async function ensureCodeInput() {
    let input = findCodeInput();
    if (input) return input;
    const exp = findExpander();
    if (exp) {
      const existing = new Set(textInputs());
      exp.click();
      for (let i = 0; i < WAIT.expandTries && !input; i++) {
        await sleep(WAIT.pollMs);
        // Fall back to a text box that appeared because of the click.
        input = findCodeInput();
        if (!input) input = revealedInput = textInputs().find(el => !existing.has(el)) || null;
      }
    }
    return input;
  }

  /**
   * Try one code. Resolves with { ok, total, message }.
   * `ok` means the page total went down (or the page reported success).
   */
  async function applyCode(code, { timeoutMs = 6000, baseline } = {}) {
    const input = await ensureCodeInput();
    if (!input) return { ok: false, message: 'Could not find the promo code box on this page' };

    const before = baseline ?? readTotal()?.amount ?? null;
    // The previous code's message is often still on screen; don't read it as this code's result.
    const stale = readFeedback(input)?.text ?? null;
    setInputValue(input, code);
    await sleep(150);
    const btn = findApplyButton(input);
    if (btn) btn.click();
    else input.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, bubbles: true }));

    const t0 = Date.now();
    let feedback = null;
    while (Date.now() - t0 < timeoutMs) {
      await sleep(300);
      const now = readTotal()?.amount ?? null;
      feedback = readFeedback(input);
      if (feedback && feedback.text === stale) feedback = null;
      // A lower total is the strongest signal; check it before any error text.
      if (before != null && now != null && now < before - 0.009) return { ok: true, total: now, message: feedback?.text || 'Total went down' };
      if (feedback?.kind === 'error') return { ok: false, total: now, message: feedback.text };
      if (feedback?.kind === 'success' && Date.now() - t0 > 1500) return { ok: true, total: now, message: feedback.text };
    }
    return { ok: false, total: readTotal()?.amount ?? before, message: 'No change in total' };
  }

  function findCheckoutButton() {
    return [...document.querySelectorAll('button, [role="button"], a')]
      .find(b => isVisible(b) && PATTERNS.checkoutText.test(text(b))) || q(SELECTORS.checkoutButton);
  }

  /** On the cart page: wait for the Checkout button to render, then press it. */
  async function clickCheckout() {
    for (let i = 0; i < WAIT.checkoutTries; i++) {
      const btn = findCheckoutButton();
      if (btn) { btn.click(); return true; }
      await sleep(WAIT.pollMs);
    }
    return false;
  }

  /** Is this a page where codes can be applied? (cart / checkout) */
  function pageKind() {
    const u = location.href;
    if (/\/p\/trade\/|confirm|checkout|placeorder/i.test(u)) return 'checkout';
    if (/cart/i.test(u)) return 'cart';
    return findCodeInput() ? 'unknown-with-code-box' : 'other';
  }

  window.__ACW_ADAPTER = { readTotal, findCodeInput, ensureCodeInput, applyCode, clickCheckout, pageKind, parseMoney, SELECTORS, PATTERNS };
})();
