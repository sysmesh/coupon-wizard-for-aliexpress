/**
 * Background service worker.
 *  - Fetches the coupon sources (the only network traffic this extension makes),
 *    parses them locally and caches the result in chrome.storage.local.
 *  - Answers GET_COUPONS messages from the popup.
 * No cart data, URLs or personal data ever leave the browser.
 */
import { PARSERS_BY_TYPE, consolidate } from './lib/parsers.js';
import { getSettings, getSources, getCache, saveCache } from './lib/store.js';
import { CART_URL } from './lib/sources.js';

async function fetchSource(source) {
  const res = await fetch(source.url, { credentials: 'omit', cache: 'no-store' });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const text = await res.text();
  const parser = PARSERS_BY_TYPE[source.type];
  if (!parser) throw new Error(`Unknown source type "${source.type}"`);
  return parser(text, { source: source.id, url: source.url });
}

export async function refreshCoupons({ force = false } = {}) {
  const [settings, sources, cache] = await Promise.all([getSettings(), getSources(), getCache()]);
  const fresh = Date.now() - cache.fetchedAt < settings.cacheMinutes * 60000;
  if (fresh && !force && cache.coupons.length) return cache;

  const all = [];
  const errors = [];
  await Promise.all(sources.filter(s => s.enabled).map(async s => {
    try {
      const granted = await chrome.permissions.contains({ origins: [new URL(s.url).origin + '/*'] });
      if (!granted) throw new Error('No host permission for this source (add its origin to manifest.json)');
      all.push(...await fetchSource(s));
    } catch (e) {
      errors.push({ source: s.name, message: e.message });
    }
  }));

  const coupons = consolidate(all);
  const next = { fetchedAt: Date.now(), coupons, errors };
  // Keep the previous list if everything failed, so the user still has something.
  if (!coupons.length && cache.coupons.length) next.coupons = cache.coupons;
  await saveCache(next);
  return next;
}

/**
 * "Support us" flow. The affiliate tracking link records the referral during the
 * s.click redirect chain, so we send the tab through it and then bring it back to
 * the page the user was on (cart / checkout):
 *   1. popup → SUPPORT_CLICK {tabId, returnUrl, affiliateLink}
 *   2. we watch the tab; once the redirect chain lands on an AliExpress page and
 *      stays put for SETTLE_MS, we navigate back to returnUrl
 *   3. for GUARD_MS after that, any stray navigation away (the landing page
 *      sometimes fires a late client-side redirect) is pushed back once more.
 * State lives in chrome.storage.session so a restarted service worker can continue.
 */
const SETTLE_MS = 1200;
const GUARD_MS = 6000;
const FLOW_TTL_MS = 90_000;
const settleTimers = new Map();

const isClickRedirect = url => /^https:\/\/s\.click\.aliexpress\./.test(url || '');
const isAliPage = url => /^https:\/\/[^/]*aliexpress\.(com|us)\//.test(url || '') && !isClickRedirect(url);
const samePage = (a, b) => {
  try { const u = new URL(a), v = new URL(b); return u.origin + u.pathname === v.origin + v.pathname; } catch { return false; }
};

async function getFlow(tabId) {
  const { supportFlow } = await chrome.storage.session.get('supportFlow');
  if (!supportFlow || supportFlow.tabId !== tabId) return null;
  if (Date.now() - supportFlow.startedAt > FLOW_TTL_MS) { await endFlow(); return null; }
  return supportFlow;
}
const setFlow = flow => chrome.storage.session.set({ supportFlow: flow });
const endFlow = () => chrome.storage.session.remove('supportFlow');

async function startSupportFlow(tabId, returnUrl, affiliateLink) {
  await setFlow({ tabId, returnUrl, phase: 'redirecting', retried: false, startedAt: Date.now() });
  await chrome.tabs.update(tabId, { url: affiliateLink });
  // Safety net: if the redirect chain produced no further events, check the tab directly.
  setTimeout(async () => {
    const flow = await getFlow(tabId);
    if (flow?.phase !== 'redirecting' || settleTimers.has(tabId)) return;
    const tab = await chrome.tabs.get(tabId).catch(() => null);
    if (tab && isAliPage(tab.url)) {
      await setFlow({ ...flow, phase: 'returning', returnedAt: Date.now() });
      chrome.tabs.update(tabId, { url: flow.returnUrl }).catch(endFlow);
    }
  }, 8000);
}

chrome.tabs.onUpdated.addListener(async (tabId, info, tab) => {
  const flow = await getFlow(tabId);
  if (!flow) return;
  const url = info.url || tab.url || '';

  if (flow.phase === 'redirecting') {
    // Debounce: every tab event (navigation, load, title, favicon…) re-arms the timer;
    // once the tab has been quiet for SETTLE_MS on an AliExpress page, go back.
    clearTimeout(settleTimers.get(tabId));
    if (!isAliPage(url)) return; // still on s.click (or elsewhere) — keep waiting
    settleTimers.set(tabId, setTimeout(async () => {
      if (!(await getFlow(tabId))) return;
      await setFlow({ ...flow, phase: 'returning', returnedAt: Date.now() });
      chrome.tabs.update(tabId, { url: flow.returnUrl }).catch(endFlow);
    }, SETTLE_MS));
    return;
  }

  if (flow.phase === 'returning') {
    if (Date.now() - flow.returnedAt > GUARD_MS) { await endFlow(); return; }
    if (info.url && !samePage(info.url, flow.returnUrl) && !isClickRedirect(info.url)) {
      // A late redirect pulled the tab away from the return page — push back once.
      if (flow.retried) { await endFlow(); return; }
      await setFlow({ ...flow, retried: true, returnedAt: Date.now() });
      chrome.tabs.update(tabId, { url: flow.returnUrl }).catch(endFlow);
    }
  }
});

chrome.tabs.onRemoved.addListener(async tabId => { if (await getFlow(tabId)) await endFlow(); });

/**
 * "Open checkout": open the cart (in the shopper's tab when it is already on
 * AliExpress, else a new tab), wait for it to load, then have the content script
 * press the cart's Checkout button.
 */
const CART_LOAD_TIMEOUT_MS = 20_000;
const CART_POLL_MS = 300;
const isCartPage = url => {
  try { return isAliPage(url) && new URL(url).pathname === new URL(CART_URL).pathname; } catch { return false; }
};

async function openCheckout(tabId) {
  const tab = tabId != null ? await chrome.tabs.get(tabId).catch(() => null) : null;
  let target = tab;
  if (!tab || !isCartPage(tab.url)) {
    target = tab && isAliPage(tab.url)
      ? await chrome.tabs.update(tab.id, { url: CART_URL })
      : await chrome.tabs.create({ url: CART_URL });
  }
  // Poll rather than listen: the content script may not be listening yet even after "complete".
  const deadline = Date.now() + CART_LOAD_TIMEOUT_MS;
  while (Date.now() < deadline) {
    const t = await chrome.tabs.get(target.id).catch(() => null);
    if (!t) return { clicked: false };
    if (t.status === 'complete' && isCartPage(t.url)) {
      const res = await chrome.tabs.sendMessage(t.id, { type: 'ACW_CLICK_CHECKOUT' }).catch(() => null);
      if (res) return res;
    }
    await new Promise(r => setTimeout(r, CART_POLL_MS));
  }
  return { clicked: false };
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === 'GET_COUPONS') {
    refreshCoupons({ force: !!msg.force }).then(sendResponse, e => sendResponse({ error: e.message }));
    return true; // async
  }
  if (msg?.type === 'OPEN_CHECKOUT') {
    openCheckout(msg.tabId).then(sendResponse, e => sendResponse({ error: e.message }));
    return true;
  }
  if (msg?.type === 'SUPPORT_CLICK') {
    startSupportFlow(msg.tabId, msg.returnUrl, msg.affiliateLink).then(() => sendResponse({ ok: true }), e => sendResponse({ error: e.message }));
    return true;
  }
  return false;
});
